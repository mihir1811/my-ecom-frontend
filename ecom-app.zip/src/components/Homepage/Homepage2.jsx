import React from "react";
import Footer2 from "../footer2";

const Homepage2 = () => {
  return (
    <>
      <section></section>
      <section></section>
      <Footer2 />
    </>
  );
};

export default Homepage2;
