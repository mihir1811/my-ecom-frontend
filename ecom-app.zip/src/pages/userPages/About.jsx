import React from "react";
import Header from "../../components/Header";
import Footer2 from "../../components/footer2";

const About = () => {
  return (
    <>
      <Header />
      <h1>about page content</h1>
      <Footer2 />
    </>
  );
};

export default About;
