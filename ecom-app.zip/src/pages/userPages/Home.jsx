import React from "react";
import Homepage1 from "../../components/Homepage/Homepage1";

const Home = () => {
  return (
    <>
      <Homepage1 />
    </>
  );
};

export default Home;
