import React from "react";
import Footer2 from "../../components/footer2";
import Header from "../../components/Header";

const Contact = () => {
  return (
    <>
      <Header />
      <h1>contact page content</h1>
      <Footer2 />
    </>
  );
};

export default Contact;
