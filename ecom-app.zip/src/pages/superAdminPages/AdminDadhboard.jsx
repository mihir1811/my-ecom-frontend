import React from "react";

const AdminDadhboard = () => {
  return <div>AdminDadhboard</div>;
};

export default AdminDadhboard;
