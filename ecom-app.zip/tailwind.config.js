export default {
  // content: [
  //   "./src/**/*.{html,js}",
  //   "./index.html"
  // ],
  content: ["src/**/*.{ts,tsx,js,jsx,htm,html}"],
  theme: {
    extend: {},
  },
  plugins: [],
};
